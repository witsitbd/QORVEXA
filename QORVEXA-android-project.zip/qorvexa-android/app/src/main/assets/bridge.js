(function () {
  if (window.__qxBridge || !window.AndroidBridge) return;
  window.__qxBridge = 1;

  function b64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = function () { rej(r.error); };
      r.readAsDataURL(blob);
    });
  }

  // The app looks for claude.use('downloads') first; route it to the phone's Downloads folder.
  window.claude = {
    use: async function (name) {
      if (name !== 'downloads') return null;
      return {
        save: async function (o) {
          var blob = o.data instanceof Blob ? o.data : new Blob([o.data]);
          AndroidBridge.saveFile(o.filename || 'file', blob.type || 'application/octet-stream', await b64(blob));
        }
      };
    }
  };

  // Any <a download> with a data: or blob: link.
  document.addEventListener('click', async function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (!a) return;
    var h = a.href || '';
    if (h.indexOf('data:') !== 0 && h.indexOf('blob:') !== 0) return;
    e.preventDefault();
    try {
      var blob = await (await fetch(h)).blob();
      AndroidBridge.saveFile(a.getAttribute('download') || 'file', blob.type || 'application/octet-stream', await b64(blob));
    } catch (x) { alert('Download failed'); }
  }, true);

  // Share sheet (email attachments etc.)
  Object.defineProperty(navigator, 'canShare', { value: function (d) { return !!d; }, configurable: true });
  Object.defineProperty(navigator, 'share', {
    configurable: true,
    value: async function (d) {
      d = d || {};
      var files = [];
      for (var i = 0; i < (d.files || []).length; i++) {
        var f = d.files[i];
        files.push({ name: f.name, type: f.type || 'application/octet-stream', data: await b64(f) });
      }
      AndroidBridge.share(JSON.stringify({ title: d.title || '', text: d.text || d.url || '', files: files }));
    }
  });

  // Clipboard (not available on file:// pages)
  if (!navigator.clipboard) {
    Object.defineProperty(navigator, 'clipboard', {
      configurable: true,
      value: {
        writeText: async function (t) { AndroidBridge.copy(String(t)); },
        readText: async function () { return ''; }
      }
    });
  }

  window.print = function () { AndroidBridge.print(); };
})();
