# QORVEXA – Android app

Your original web app is bundled unchanged in `app/src/main/assets/index.html` and runs inside an Android WebView.
All data stays on the phone (same localStorage as the web version – it does NOT carry over from the browser; use the app's export/backup if it has one).

## Build the APK

### Option A – Android Studio (PC)
1. Unzip, open the folder in Android Studio (Hedgehog or newer), let Gradle sync.
2. Build > Build APK(s). Result: `app/build/outputs/apk/debug/app-debug.apk`.

### Option B – GitHub (no install)
1. Create a free GitHub repository and upload everything in this folder (keep the folder structure, including `.github/workflows/build.yml`).
2. Open the repo's **Actions** tab > **Build APK** > wait for the green tick (~3 min).
3. Open the run, download the **QORVEXA-apk** artifact, unzip, and install `app-debug.apk` on your phone (allow "Install unknown apps").

To update the app later, replace `app/src/main/assets/index.html` and rebuild.
